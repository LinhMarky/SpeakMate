package com.example.speakmate;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;
import java.util.Locale;

public class FlashcardsFragment extends Fragment {

    private List<FlashcardDeck> decks;

    public FlashcardsFragment() {
        super(R.layout.fragment_flashcards);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        DemoFlashcardRepository repository =
                new DemoFlashcardRepository();

        decks = repository.getDecks();

        EditText search = view.findViewById(R.id.etSearchDeck);
        LinearLayout container =
                view.findViewById(R.id.deckContainer);
        TextView countText =
                view.findViewById(R.id.tvDeckCount);

        showDecks(
                search.getText().toString(),
                container,
                countText
        );

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence s, int start, int count, int after
            ) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s, int start, int before, int count
            ) {
                showDecks(s.toString(), container, countText);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        view.findViewById(R.id.btnCreateDeckAi)
                .setOnClickListener(v -> showDemoMessage(
                        "Màn hình tạo thẻ AI sẽ được nối ở bước sau."
                ));

        view.findViewById(R.id.btnCreateDeckManual)
                .setOnClickListener(v -> showDemoMessage(
                        "Màn hình tạo thủ công sẽ được nối ở bước sau."
                ));
    }

    private void showDecks(
            String keyword,
            LinearLayout container,
            TextView countText
    ) {
        container.removeAllViews();

        String query = keyword.trim().toLowerCase(Locale.ROOT);
        int visibleCount = 0;

        for (FlashcardDeck deck : decks) {
            if (!deck.getName().toLowerCase(Locale.ROOT)
                    .contains(query)) {
                continue;
            }

            visibleCount++;

            View item = getLayoutInflater().inflate(
                    R.layout.item_flashcard_deck,
                    container,
                    false
            );

            TextView name = item.findViewById(R.id.tvDeckName);
            TextView info = item.findViewById(R.id.tvDeckInfo);
            TextView progressText =
                    item.findViewById(R.id.tvDeckProgress);
            ProgressBar progress =
                    item.findViewById(R.id.progressDeck);

            name.setText(deck.getName());

            info.setText(
                    deck.getTotalCards() + " từ · " + deck.getLevel()
            );

            int percentage = deck.getTotalCards() == 0
                    ? 0
                    : Math.round(
                    deck.getLearnedCards() * 100f
                    / deck.getTotalCards()
            );

            progress.setProgress(percentage);

            progressText.setText(
                    deck.getLearnedCards()
                            + "/" + deck.getTotalCards()
                            + " từ đã nhớ · " + percentage + "%"
            );

            item.setOnClickListener(v ->
                    getParentFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragmentContainer,
                                    DeckDetailFragment.newInstance(deck.getId())
                            )
                            .addToBackStack("deck_detail")
                            .commit()
            );

            container.addView(item);
        }

        if (visibleCount == 0) {
            countText.setText("Không tìm thấy bộ thẻ phù hợp.");
        } else {
            countText.setText(
                    visibleCount + " bộ thẻ · Dữ liệu demo"
            );
        }
    }

    private void showDemoMessage(String message) {
        Toast.makeText(
                requireContext(),
                message,
                Toast.LENGTH_SHORT
        ).show();
    }
}