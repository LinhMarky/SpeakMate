package com.example.speakmate;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.core.view.ViewCompat;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;

public class ChatFragment extends Fragment {

    private String level;
    private String topic;

    private final ArrayList<String> messages = new ArrayList<>();
    private final ArrayList<Boolean> userMessages = new ArrayList<>();

    private LinearLayout messageContainer;
    private ScrollView chatScroll;

    public ChatFragment() {
        super(R.layout.fragment_chat);
    }

    public static ChatFragment newInstance(String level, String topic) {
        ChatFragment fragment = new ChatFragment();

        Bundle arguments = new Bundle();
        arguments.putString("level", level);
        arguments.putString("topic", topic);
        fragment.setArguments(arguments);

        return fragment;
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        Bundle arguments = requireArguments();
        level = arguments.getString("level", "A2");
        topic = arguments.getString("topic", "Ordering Food");

        TextView topicText = view.findViewById(R.id.tvChatTopic);
        TextView levelText = view.findViewById(R.id.tvChatLevel);
        EditText input = view.findViewById(R.id.etMessage);

        messageContainer = view.findViewById(R.id.messageContainer);
        chatScroll = view.findViewById(R.id.chatScroll);

        topicText.setText(topic);
        levelText.setText("Trình độ " + level);

        if (savedInstanceState != null && messages.isEmpty()) {
            ArrayList<String> savedMessages =
                    savedInstanceState.getStringArrayList("messages");
            boolean[] savedRoles =
                    savedInstanceState.getBooleanArray("roles");

            if (savedMessages != null && savedRoles != null
                    && savedMessages.size() == savedRoles.length) {
                messages.addAll(savedMessages);

                for (boolean role : savedRoles) {
                    userMessages.add(role);
                }
            }
        }

        if (messages.isEmpty()) {
            messages.add(getOpeningMessage());
            userMessages.add(false);
        }

        for (int i = 0; i < messages.size(); i++) {
            displayMessage(messages.get(i), userMessages.get(i));
        }

        view.findViewById(R.id.btnBackChat)
                .setOnClickListener(v -> confirmEndSession());

        view.findViewById(R.id.btnEndChat)
                .setOnClickListener(v -> confirmEndSession());

        view.findViewById(R.id.btnSendMessage)
                .setOnClickListener(v -> {
                    String content = input.getText().toString().trim();

                    if (content.isEmpty()) {
                        input.setError("Bạn hãy nhập câu trả lời.");
                        return;
                    }

                    addMessage(content, true);
                    input.setText("");

                    // Phản hồi cố định để kiểm tra giao diện.
                    // Phần này sẽ chuyển sang repository khi nối backend.
                    addMessage(getDemoReply(), false);

                    scrollToBottom();
                });

        scrollToBottom();
    }

    private void confirmEndSession() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Kết thúc phiên luyện?")
                .setMessage(
                        "Bạn có thể xem tổng kết hoặc thoát phiên demo."
                )
                .setNegativeButton("Tiếp tục luyện", null)

                .setNeutralButton("Thoát phiên", (dialog, which) -> {
                    hideKeyboard();

                    com.google.android.material.bottomnavigation.BottomNavigationView
                            navigation = requireActivity()
                            .findViewById(R.id.bottomNavigation);

                    navigation.setSelectedItemId(R.id.nav_home);
                })

                .setPositiveButton("Xem tổng kết", (dialog, which) -> {
                    hideKeyboard();

                    int userTurnCount = 0;

                    for (boolean fromUser : userMessages) {
                        if (fromUser) {
                            userTurnCount++;
                        }
                    }

                    getParentFragmentManager()
                            .beginTransaction()
                            .replace(
                                    R.id.fragmentContainer,
                                    SpeakingResultFragment.newInstance(
                                            level,
                                            topic,
                                            userTurnCount
                                    )
                            )
                            .commit();
                })
                .show();
    }

    private void hideKeyboard() {
        View currentView = getView();

        if (currentView == null) {
            return;
        }

        androidx.core.view.WindowInsetsControllerCompat controller =
                ViewCompat.getWindowInsetsController(currentView);

        if (controller != null) {
            controller.hide(
                    androidx.core.view.WindowInsetsCompat.Type.ime()
            );
        }

        currentView.clearFocus();
    }

    private String getOpeningMessage() {
        switch (topic) {
            case "Introducing Yourself":
                return "Hi! I'm your practice partner. What's your name?";

            case "Travel":
                return "Hello! Where would you like to travel?";

            case "University Life":
                return "Hi! What do you study at university?";

            default:
                return "Welcome! What would you like to order?";
        }
    }

    private String getDemoReply() {
        switch (topic) {
            case "Introducing Yourself":
                return "Nice to meet you! What do you enjoy doing?";

            case "Travel":
                return "What would you like to do there?";

            case "University Life":
                return "What do you enjoy most about university?";

            default:
                return "Would you like something to drink?";
        }
    }

    private void addMessage(String content, boolean fromUser) {
        messages.add(content);
        userMessages.add(fromUser);
        displayMessage(content, fromUser);
    }

    private void displayMessage(String content, boolean fromUser) {
        LinearLayout row = new LinearLayout(requireContext());
        row.setGravity(fromUser ? Gravity.END : Gravity.START);

        LinearLayout.LayoutParams rowParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        rowParams.bottomMargin = dp(14);
        row.setLayoutParams(rowParams);

        TextView bubble = new TextView(requireContext());
        bubble.setText(content);
        bubble.setTextSize(16);
        bubble.setTextColor(ContextCompat.getColor(
                requireContext(), R.color.sm_text_primary
        ));
        bubble.setBackgroundResource(
                fromUser
                        ? R.drawable.bg_button_primary
                        : R.drawable.bg_card
        );
        bubble.setPadding(dp(16), dp(14), dp(16), dp(14));

        // Giới hạn chiều rộng để tin nhắn có dạng bong bóng.
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        bubble.setMaxWidth((int) (screenWidth * 0.76f));

        row.addView(
                bubble,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        messageContainer.addView(row);
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }

    private void scrollToBottom() {
        ScrollView scroll = chatScroll;
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putStringArrayList(
                "messages", new ArrayList<>(messages)
        );

        boolean[] roles = new boolean[userMessages.size()];

        for (int i = 0; i < userMessages.size(); i++) {
            roles[i] = userMessages.get(i);
        }

        outState.putBooleanArray("roles", roles);
    }

    @Override
    public void onStart() {
        super.onStart();

        View navigation = requireActivity()
                .findViewById(R.id.bottomNavigation);

        navigation.setVisibility(View.GONE);

        ViewCompat.requestApplyInsets(
                requireActivity().findViewById(R.id.main)
        );
    }

    @Override
    public void onStop() {
        View navigation = requireActivity()
                .findViewById(R.id.bottomNavigation);

        navigation.setVisibility(View.VISIBLE);

        ViewCompat.requestApplyInsets(
                requireActivity().findViewById(R.id.main)
        );

        super.onStop();
    }

    @Override
    public void onDestroyView() {
        messageContainer = null;
        chatScroll = null;
        super.onDestroyView();
    }
}