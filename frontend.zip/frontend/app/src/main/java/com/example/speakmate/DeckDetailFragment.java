package com.example.speakmate;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

public class DeckDetailFragment extends Fragment {

    public DeckDetailFragment() {
        super(R.layout.fragment_deck_detail);
    }

    public static DeckDetailFragment newInstance(String deckId) {
        DeckDetailFragment fragment = new DeckDetailFragment();

        Bundle arguments = new Bundle();
        arguments.putString("deckId", deckId);
        fragment.setArguments(arguments);

        return fragment;
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        String deckId = requireArguments()
                .getString("deckId", "");

        DemoFlashcardRepository repository =
                new DemoFlashcardRepository();

        FlashcardDeck deck = repository.getDeckById(deckId);

        view.findViewById(R.id.btnBackDeck)
                .setOnClickListener(v ->
                        getParentFragmentManager().popBackStack());

        if (deck == null) {
            TextView title =
                    view.findViewById(R.id.tvDetailDeckName);
            title.setText("Không tìm thấy bộ thẻ");

            view.findViewById(R.id.btnStudyDeck)
                    .setEnabled(false);

            return;
        }

        List<Flashcard> cards = repository.getCards(deckId);

        TextView title =
                view.findViewById(R.id.tvDetailDeckName);
        TextView info =
                view.findViewById(R.id.tvDetailDeckInfo);
        LinearLayout container =
                view.findViewById(R.id.cardListContainer);

        title.setText(deck.getName());

        info.setText(
                "Trình độ: " + deck.getLevel()
                        + "\nSố từ: " + cards.size()
                        + "\nĐã nhớ: " + deck.getLearnedCards()
                        + "\nNguồn: Dữ liệu demo"
        );

        for (Flashcard card : cards) {
            View item = getLayoutInflater().inflate(
                    R.layout.item_vocabulary,
                    container,
                    false
            );

            TextView word =
                    item.findViewById(R.id.tvVocabularyWord);
            TextView meaning =
                    item.findViewById(R.id.tvVocabularyMeaning);
            TextView example =
                    item.findViewById(R.id.tvVocabularyExample);

            word.setText(card.getWord());
            meaning.setText(card.getMeaning());
            example.setText(card.getExample());

            container.addView(item);
        }

        View studyButton = view.findViewById(R.id.btnStudyDeck);
        studyButton.setEnabled(!cards.isEmpty());

        studyButton.setOnClickListener(v ->
                Toast.makeText(
                        requireContext(),
                        "Sẽ mở phần học bộ: " + deck.getName(),
                        Toast.LENGTH_SHORT
                ).show());
    }
}