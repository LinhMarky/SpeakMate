package com.example.speakmate;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Dùng biểu tượng hệ thống sáng trên nền tối.
        WindowCompat.getInsetsController(
                getWindow(), getWindow().getDecorView()
        ).setAppearanceLightStatusBars(false);

        WindowCompat.getInsetsController(
                getWindow(), getWindow().getDecorView()
        ).setAppearanceLightNavigationBars(false);

        View main = findViewById(R.id.main);

        ViewCompat.setOnApplyWindowInsetsListener(main, (view, insets) -> {
            Insets systemBars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
            );

            Insets keyboard = insets.getInsets(
                    WindowInsetsCompat.Type.ime()
            );

            View navigation = findViewById(R.id.bottomNavigation);

            boolean navigationVisible =
                    navigation.getVisibility() == View.VISIBLE;

            int bottomPadding;

            if (navigationVisible) {
                // Thanh điều hướng tự xử lý khoảng trống hệ thống.
                bottomPadding = 0;
            } else {
                // Khi chat, dành chỗ cho bàn phím hoặc thanh hệ thống.
                bottomPadding = Math.max(
                        systemBars.bottom,
                        keyboard.bottom
                );
            }

            view.setPadding(
                    systemBars.left,
                    systemBars.top,
                    systemBars.right,
                    bottomPadding
            );

            return insets;
        });

        ViewCompat.requestApplyInsets(main);

        BottomNavigationView navigation =
                findViewById(R.id.bottomNavigation);

        navigation.setOnItemSelectedListener(item -> {

            // Đóng các màn hình con trước khi chuyển sang tab chính.
            getSupportFragmentManager().popBackStackImmediate(
                    null,
                    androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE
            );

            Fragment fragment;

            if (item.getItemId() == R.id.nav_home) {
                fragment = new HomeFragment();

            } else if (item.getItemId() == R.id.nav_speaking) {
                fragment = new SpeakingFragment();

            } else if (item.getItemId() == R.id.nav_flashcards) {
                fragment = new FlashcardsFragment();

            } else if (item.getItemId() == R.id.nav_profile) {
                fragment = PlaceholderFragment.newInstance("Cá nhân");

            } else {
                return false;
            }

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .commit();

            return true;
        });

        if (savedInstanceState == null) {
            navigation.setSelectedItemId(R.id.nav_home);
        }
    }
}